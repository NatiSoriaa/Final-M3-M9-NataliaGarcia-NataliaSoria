

public class BooksApiProduct{
    public string Title { get; set; } = string.Empty; //title
    public string Author { get; set; }// author_name[0]
    public int CoverID { get; set; } // cover_i
    public string Urlcover { get; set; } = string.Empty; //cover_url
    public int PublishedDate { get; set; } //first_publish_year
    }
    
