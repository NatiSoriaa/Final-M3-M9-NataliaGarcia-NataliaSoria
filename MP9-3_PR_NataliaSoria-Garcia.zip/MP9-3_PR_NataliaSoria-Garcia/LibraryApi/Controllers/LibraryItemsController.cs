using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryApi.Models;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace LibraryApi.Controllers;

[ApiController]
[Route("[controller]")]
public class LibraryItemsController : ControllerBase
{
    private readonly LibraryContext _context;

    public LibraryItemsController(LibraryContext context)
    {
        _context = context;
    }

    // GET: api/TodoItems
    [HttpGet]

    //DEVOLVEMOS TODOS LOS LIBROS DE NUESTRA BBDD
    public async Task<ActionResult<IEnumerable<LibraryItem>>> GetLibraryItems()
    {
        
        return await _context.LibraryItems.ToListAsync();
    }
}

